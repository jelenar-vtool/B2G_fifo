
This is a repository for Vtool's training program that contains all the files related to the training program. 

Structure: 
  1. scripts - contains runme and other scripts
  2. ral_lab - lab to learn about ral
  3. uvc_template_generator - python script to generate files
  4. verif_training - basic template for training programs
  5. rtl - contains the design with bugs
  6. sva_lab - design for SVA lab
