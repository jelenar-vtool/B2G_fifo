The design contains 9 bugs. The bugs and fixes can be found on Vtool's drive under Documents related to training procedure.
