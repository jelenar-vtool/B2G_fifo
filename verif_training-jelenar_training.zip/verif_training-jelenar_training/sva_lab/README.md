# assertions_proj
Repo for few examples of assertions in System Verilog

To run the sim:
run_xlm
